#!/usr/bin/env bash
set -euo pipefail

# Argument Parsing
VAULT_PATH="${1:-}"
SOURCE_URL="${2:-}"
RUN_ID="${3:-$(uuidgen 2>/dev/null || date +%s)}"

if [[ -z "${VAULT_PATH}" || -z "${SOURCE_URL}" ]]; then
    echo "[ERROR] Missing arguments to store_vault.sh. Usage: store_vault.sh <vault_path> <source_url> [run_id]" >&2
    exit 1
fi

DB_FILE="${VAULT_DIR:-./vaults}/../storage.sqlite"

# Ensure database and core architecture table exist with WAL optimizations
sqlite3 "${DB_FILE}" << 'SQL'
PRAGMA journal_mode=WAL;
CREATE TABLE IF NOT EXISTS vault_index (
    sha256 TEXT PRIMARY KEY,
    source_url TEXT NOT NULL,
    run_id TEXT NOT NULL,
    stored_at TEXT NOT NULL,
    vault_path TEXT NOT NULL
);
SQL

# Compute unique hash signature
if [[ ! -f "${VAULT_PATH}" ]]; then
    echo "[ERROR] Target vault payload not found at ${VAULT_PATH}" >&2
    exit 1
fi
payload_hash=$(sha256sum "${VAULT_PATH}" | cut -d' ' -f1)

# Atomic conditional execution loop
sqlite3 "${DB_FILE}" <<SQL
INSERT OR IGNORE INTO vault_index (sha256, source_url, run_id, stored_at, vault_path)
VALUES ('${payload_hash}', '${SOURCE_URL}', '${RUN_ID}', datetime('now'), '${VAULT_PATH}');
SQL

# Check transaction adjustments to confirm uniqueness
changes=$(sqlite3 "${DB_FILE}" "SELECT changes();")

if [[ "${changes}" -eq 0 ]]; then
    echo ":: [DEDUPLICATION MATRIX] Duplicate hash signature [${payload_hash:0:12}...] matched. Discarding raw vault."
    rm -f "${VAULT_PATH}"
    exit 0
else
    echo ":: [STORAGE MATRICES] Successfully committed unique vault map to WAL index."
    exit 0
fi
